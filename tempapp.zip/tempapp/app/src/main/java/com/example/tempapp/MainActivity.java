package com.example.tempapp;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.RadioButton;
import android.widget.Toast;

// let the user enter a temperatures in celsius or in fahrenhite
// convert from the not empty temperature to the empty one
//if both null show a message says enter the temperature to convert
public class MainActivity extends AppCompatActivity implements View.OnClickListener{
    EditText cel, fah;
    Button bok;
    RadioButton ctof,ftoc;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        cel=findViewById(R.id.celtx);
        fah=findViewById(R.id.fatx);
        bok=findViewById(R.id.conve);
        ctof=findViewById(R.id.rbc2f);
        ftoc=findViewById(R.id.rbf2c);
        bok.setOnClickListener(this);
    }

    public void onClick(View view) {
        double f,c;
        if (cel.getText().toString().equals("") && fah.getText().toString().equals(""))
            //when both are empty
            Toast.makeText(getApplicationContext(), "Please enter the temperature to convert it", Toast.LENGTH_LONG).show();
        if(ctof.isChecked()){
            // convert from cel to fah
            if (!cel.getText().toString().equals("")){
                c = Double.parseDouble(cel.getText().toString());
                f = 9 * c / 5 + 32;
                String fa = String.format("%.1f", f);
                fah.setText(fa);
            }
            else
                Toast.makeText(getApplicationContext(), "Please enter the Cel temperature to convert it", Toast.LENGTH_LONG).show();

        }

        else if (ftoc.isChecked()){
            //convert from Fah to Cel
            if (!fah.getText().toString().equals("")){
                f = Double.parseDouble(fah.getText().toString());
                c = 5 * (f - 32) / 9;
                String ce = String.format("%.1f", c);
                cel.setText(ce);
            }
            else
                Toast.makeText(getApplicationContext(), "Please enter the Fah temperature to convert it", Toast.LENGTH_LONG).show();
        }

    }
}
